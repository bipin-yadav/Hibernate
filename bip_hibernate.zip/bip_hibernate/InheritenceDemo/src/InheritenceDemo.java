
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author BI301759
 */
public class InheritenceDemo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        A ob1 = new A();
        ob1.setName("bipin");
        B ob2 =new B();
        ob2.setName("bipinB");
        ob2.setDept("Digital");
        C ob3 = new C();
        ob3.setName("bipinC");
        ob3.setLoc("Bangalore");
        
        Session session  = HibernateUtil.getSessionFactory().openSession();
        Transaction trn = session.beginTransaction();   
        
        try{
         
        session.save(ob1);
                
        trn.commit();
        }
        catch(HibernateException he){
            System.out.println(he);
        }
        
        
    }
}
